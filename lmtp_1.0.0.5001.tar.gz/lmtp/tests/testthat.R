library(testthat)
library(lmtp)

test_check("lmtp")
