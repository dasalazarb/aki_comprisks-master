.onAttach <- function(libname, pkgname) {
  packageStartupMessage("NOT MAIN VERSION OF LMTP! THIS IS THE SL3 COMPATIBLE VERSION.")
}
